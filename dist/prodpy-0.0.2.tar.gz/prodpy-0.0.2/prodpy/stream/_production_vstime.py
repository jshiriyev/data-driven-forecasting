import datetime

import pandas as pd

import plotly.graph_objects as go

from plotly.subplots import make_subplots

def plot1(frame:pd.DataFrame):

    fig = make_subplots(rows=4, cols=1, shared_xaxes=True, vertical_spacing=0.02,
        specs=[[{}], [{"secondary_y": True}], [{"secondary_y": True}], [{}]])

    plot1 = go.Scatter(
        x = frame["DATE"],
        y = frame["OIL TONS/DAY"],
        mode = 'markers',
        marker = dict(color='blue', size=2),
        name = 'Oil Tons/day'
        )

    plot21 = go.Scatter(
        x = frame["DATE"],
        y = frame["WATER M3/DAY"],
        mode = 'markers',
        marker = dict(size=2,color='blue'),
        name = 'Water m3/day',
        )

    plot22 = go.Scatter(
        x = frame["DATE"],
        y = frame["GAS KM3/DAY"],
        mode = 'markers',
        marker = dict(size=3, color='red'),
        name = 'Gas km3/day',
        yaxis = 'y2'
        )

    plot31 = go.Scatter(
        x = frame["DATE"],
        y = frame["CHOCKE"],
        mode = 'markers',
        marker = dict(size=2,color='blue'),
        name = 'Chocke')

    plot32 = go.Scatter(
        x = frame["DATE"],
        y = frame["DAYS"],
        mode = 'markers', 
        marker = dict(size=3,color='red'),
        name = 'Operation Days',
        yaxis = 'y2')

    plot4 = go.Scatter(
        x = frame["DATE"],
        y = frame["METHOD"],
        mode = 'lines', 
        line = dict(color='blue',width=1),
        name = 'Lift Method',
        )

    fig.add_trace(plot1,row=1,col=1)
    fig.add_trace(plot21,row=2,col=1)
    fig.add_trace(plot22,row=2,col=1,secondary_y=True)
    fig.add_trace(plot31,row=3,col=1)
    fig.add_trace(plot32,row=3,col=1,secondary_y=True)
    fig.add_trace(plot4,row=4,col=1)

    fig.update_xaxes(showticklabels=True, row=1, col=1)  # Hide on top plot

    fig.update_yaxes(title_text="OIL TONS/DAY", row=1, col=1)
    fig.update_yaxes(title_text="WATER M3/DAY", row=2, col=1)
    fig.update_yaxes(title_text="GAS KM3/DAY", row=2, col=1, secondary_y=True, showgrid=False)
    fig.update_yaxes(title_text="CHOCKE", row=3, col=1)
    fig.update_yaxes(title_text="DAYS", row=3, col=1, secondary_y=True, showgrid=False)
    fig.update_yaxes(title_text="LIFT METHOD", row=4, col=1)

    fig.add_vline(x=datetime.date.today(),line=dict(color='red',dash='dash',width=0.5))

    fig.update_layout(height=1200,showlegend=False)

    return fig

def plot2(frame:pd.DataFrame):
    # Ensure datetime
    d = frame.copy()

    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Oil (primary)
    fig.add_trace(
        go.Scatter(
            x=d.date, y=d.orate,
            mode="lines",
            name="Oil (ton/day)",
            hovertemplate="%{x|%Y-%m-%d}<br>Oil: %{y:.2f} ton/day<extra></extra>",
            line=dict(color='green'),
        ),
        secondary_y=False,
    )

    # Water (primary)
    fig.add_trace(
        go.Scatter(
            x=d.date, y=d.wrate,
            mode="lines",
            name="Water (m³/day)",
            hovertemplate="%{x|%Y-%m-%d}<br>Water: %{y:.2f} m³/day<extra></extra>",
            line=dict(color='blue')
        ),
        secondary_y=False,
    )

    # Gas (secondary)
    fig.add_trace(
        go.Scatter(
            x=d.date, y=d.grate,
            mode="lines",
            name="Gas (km³/day)",
            hovertemplate="%{x|%Y-%m-%d}<br>Gas: %{y:.4f} km³/day<extra></extra>",
            line=dict(color='red'),
        ),
        secondary_y=True,
    )

    fig.update_layout(
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
        hovermode="x unified",
        margin=dict(l=60, r=60, t=60, b=40),
        height=520,
        xaxis=dict(
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=3, label="3m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ]),
                x=0.95,xanchor="auto",
                y=1.05,yanchor="top",
            ),
            rangeslider=dict(visible=True),
            type="date",
        )
    )

    fig.update_yaxes(title_text="Oil (ton/day) & Water (m³/day)", secondary_y=False)
    fig.update_yaxes(title_text="Gas (km³/day)", secondary_y=True)

    return fig