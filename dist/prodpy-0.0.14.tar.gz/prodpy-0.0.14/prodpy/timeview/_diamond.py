import pandas

import plotly.graph_objects as go

class Diamond():

	def __init__(self,datehead:str,ratehead:str):
		"""Initializing the class with date and rate column keys. The date and rate
		values are used for the optimization and forecasting of pandas.DataFrames."""

		self._datehead = datehead
		self._ratehead = ratehead

	@property
	def datehead(self):
		return self._datehead

	@property
	def ratehead(self):
		return self._ratehead

	def measured(self,figure:go.Figure,frame:pandas.DataFrame,**kwargs):

		figure.add_trace(
			go.Scatter(
				x = frame[self.datehead],
				y = frame[self.ratehead],
				mode = 'markers',
				marker = kwargs,
			)
		)

		return figure

	def computed(self,figure:go.Figure,frame:pandas.DataFrame,**kwargs):

		figure.add_trace(
			go.Scatter(
				x = frame[self.datehead],
				y = frame[self.ratehead],
				mode = 'lines',
				line = kwargs,
			)
		)

		return figure