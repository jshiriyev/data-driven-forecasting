import unittest

if __name__ == "__main__":
    import dirsetup

from textio import xlsheet
from textio import loadxlsheet
from textio import xlbatch

class TestXlSheet(unittest.TestCase):

    def test_init(self):

        pass

class TestLoadXl(unittest.TestCase):

    def test_init(self):

        pass

class TestXlBatch(unittest.TestCase):

    def test_init(self):

        pass

if __name__ == "__main__":

    unittest.main()