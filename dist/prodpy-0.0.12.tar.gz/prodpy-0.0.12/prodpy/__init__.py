from . import stream
from . import onepage

from ._allocate import Allocate

from . import decline