from . import wellbore

from ._table import prods, perfs

from . import allocate
from . import onepage

from . import decline