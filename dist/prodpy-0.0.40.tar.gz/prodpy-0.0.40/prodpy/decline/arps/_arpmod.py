import numpy

from ._genmod import GenModel
from ._marshal import Marshal

class Arps(GenModel):

	def __init__(self,*args,**kwargs):

		super(Arps,self).__init__(*args,**kwargs)

	def __model(self):

		return Marshal.model(self.xp)(*self.props)

	def ycal(self,x:numpy.ndarray):

		return self.__model.ycal(x)

	def ycum(self,x:numpy.ndarray):

		return self.__model.ycum(x)

	def regress(self,x:numpy.ndarray,yobs:numpy.ndarray,xi:float=None):
		"""Returns regression results after linearization."""
		return self.__model.regress(x,yobs,xi)

	def model(self,x:numpy.ndarray,yobs:numpy.ndarray,xi:float=None):
		"""Returns an exponential model that fits observation values."""
		return self.__model.model(x,yobs,xi)