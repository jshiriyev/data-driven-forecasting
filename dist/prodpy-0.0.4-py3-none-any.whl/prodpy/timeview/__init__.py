from ._template import Template

from ._outlook import Outlook